export const valores=[
  { color:"#ea4335",
    desde:0,
    altura:52 },
  { color:"#34a853",
    desde:0,
    altura:103 },
  { color:"#fbbc05",
    desde:0,
    altura:77 },
  { color:"#4285f4",
    desde:0,
    altura:84 },
  { desde:0,
    altura:76 }      
]