export const cuadros=[
  "https://www.html6.es/img/rey_ervigio.png",
  "https://www.html6.es/img/rey_ataulfo.png",
  "https://www.html6.es/img/rey_atanagildo.png",
  "https://www.html6.es/img/rey_leogivildo.png",
  "https://www.html6.es/img/rey_sisebuto.png",
  "https://www.html6.es/img/rey_recesvinto.png"
]
